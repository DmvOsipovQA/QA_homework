<h1>Учебный репозиторий</h1>
<img src="img/logo_cat.png" alt="нет картинки">
<ul>
    <li>
        <a href="https://vk.com">BK</a>
    </li>
    <li>
        <a href="https://ya.ru"><img src="img/logo_cat.png" style="wigth:30px;height:30px"></a>
    </li>
</ul>
